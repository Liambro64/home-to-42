#include <unistd.h>

int	ft_strlen(char	*src)
{
	int i;

	i = 1;
	while (*src)
	{
		src++;
		i++;
	}
	return (i);
}

int main(int argc, char *argv[])
{
	write(1, argv[0], ft_strlen(argv[0]));
	return 0;
}
