/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/23 16:58:44 by marvin            #+#    #+#             */
/*   Updated: 2023/11/23 16:58:44 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char	*src)
{
	int i;

	i = 1;
	while (*src)
	{
		src++;
		i++;
	}
	return (i);
}

int	ft_strcmp(char *s1, char *s2)
{
	while (*s1 == *s2)
	{
		*s1++;
		*s2++;
		if (*s1 == 0)
			return (*s1 - *s2);
	}
	return (*s1 - *s2);
}

char **sort(int argc, char **argv)
{
	char *tmp;
	int i;

	i = 1;
	while (i < argc)
	{
		while (i < argc - 1)
		{
			if (ft_strcmp(argv[i], argv[i + 1]) > 0)
			{
				tmp = argv[i + 1];
				argv[i + 1] = argv[i];
				argv[i] = tmp;
			}
			i++;
		}
		i = 1;
		argc--;
	}
	return (argv);
}

int main(int argc, char *argv[])
{
    char **sorted_args;
	int i;
	
    sorted_args = sort(argc, argv);
	i = 1;
    
	while (argv[i])
	{
		write(1, argv[i], ft_strlen(argv[i]));
		write(1, "\n", 1);
		i++;
	}
	return 0;
}